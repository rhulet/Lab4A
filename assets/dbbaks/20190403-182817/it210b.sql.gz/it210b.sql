-- MySQL dump 10.13  Distrib 5.7.25, for Linux (x86_64)
--
-- Host: localhost    Database: it210b
-- ------------------------------------------------------
-- Server version	5.7.25-0ubuntu0.18.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cross_server_keys`
--

DROP TABLE IF EXISTS `cross_server_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cross_server_keys` (
  `csk_index` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`csk_index`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cross_server_keys`
--

LOCK TABLES `cross_server_keys` WRITE;
/*!40000 ALTER TABLE `cross_server_keys` DISABLE KEYS */;
INSERT INTO `cross_server_keys` VALUES (1,'371637cb-6ff0-4e6e-b758-995ac6c5cb65','ryanhulet34@gmail.com','2019-03-19 13:12:20','2019-03-19 13:12:20'),(2,'312e67d4-2c78-4ef8-aa82-582e873fa3d9','ryanhulet34@gmail.com','2019-03-19 20:21:09','2019-03-19 20:21:09'),(3,'e3d3a9f4-14c4-4679-98a0-06a970e90efa','ryanhulet34@gmail.com','2019-03-20 00:38:57','2019-03-20 00:38:57');
/*!40000 ALTER TABLE `cross_server_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `imageId` int(11) NOT NULL AUTO_INCREMENT,
  `imagePath` varchar(255) DEFAULT NULL,
  `uploaded` int(11) NOT NULL DEFAULT '0',
  `imageApproved` varchar(255) DEFAULT NULL,
  `altText` varchar(255) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `numLikes` int(11) DEFAULT '0',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`imageId`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (1,'/images/image1.jpg',1,'1','testing1',4,46,'2013-08-20 15:45:52','2019-04-02 16:15:09'),(2,'/images/image1.jpg',1,'1','testing1',3,18,'2013-08-21 10:22:16','2019-04-02 16:16:29'),(3,'/images/image2.jpg',1,'0','testing2',4,42,'2013-08-21 10:22:39','2019-04-02 16:16:29'),(4,'/images/image3.jpg',1,'0','testing3',3,12,'2013-08-21 10:22:50','2019-04-02 16:16:29'),(5,'/images/image5.jpg',1,'1','testing5',3,13,'2013-08-21 10:24:59','2019-04-02 16:16:29'),(6,'/images/image6.jpg',1,'1','testing6',4,13,'2013-08-21 10:25:09','2019-04-02 16:16:29'),(7,'/images/image7.jpg',1,'1','testing7',3,11,'2013-08-21 10:25:16','2019-04-02 16:16:29'),(8,'/images/image8.jpg',1,'1','testing8',2,5,'2013-08-22 12:49:37','2019-04-02 16:16:29'),(9,'/images/image9.jpg',1,'1','testing9',3,10,'2013-08-22 13:24:42','2019-04-02 16:16:29'),(10,'/images/image10.jpg',1,'1','testing10',3,10,'2013-08-22 15:03:03','2019-04-02 16:16:29'),(11,'/images/image11.jpg',1,'1','testing11',4,6,'2013-08-22 15:03:29','2019-04-02 16:16:29'),(12,'/images/image12.jpg',1,'1','testing12',3,7,'2013-08-23 13:34:20','2019-04-02 16:16:29'),(13,'/images/image13.jpg',1,'1','testing13',3,5,'2013-08-26 09:48:56','2019-04-02 16:16:29'),(14,'/images/image6.jpg',1,'1','testing6',4,13,'2013-08-21 10:25:09','2019-04-02 16:16:29'),(21,'/images/53abf00a-44a4-4080-91fa-a30e048f97d920180717_Ameritech_1468.jpg',1,'0','DID IT WORK?',5,0,'2019-03-19 17:39:24','2019-04-03 18:11:15');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `loggedIn` int(11) DEFAULT NULL,
  `isAdmin` tinyint(1) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'user','user@user.com','12dea96fec20593566ab75692c9949596833adc9',0,0,'2013-08-21 10:22:16','2013-08-21 10:22:16'),(2,'admin','admin@admin.com','d033e22ae348aeb5660fc2140aec35850c4da997',0,0,'2013-08-21 10:22:16','2013-08-21 10:22:16'),(3,'jed','test@gmail.com','123456789',1,0,'2013-08-21 10:22:16','2013-08-21 10:22:16'),(4,'tester','tester@test.com','0987654321',0,0,'2013-08-21 10:22:16','2013-08-21 10:22:16'),(5,'Ryan','ryanhulet34@gmail.com','98765432109876543210987654321',1,0,'2019-03-13 02:41:59','2019-03-20 00:38:57');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-03 18:29:03
